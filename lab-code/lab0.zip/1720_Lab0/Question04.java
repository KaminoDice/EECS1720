

/**
 * This app derives and prints out the area of a rectangle that is 8 units wide
 * and 3 units high.
 * 
 * @author EECS1720 
 * 
 */
public class Question04 {

	public static void main(String[] args) {
		/*
		 * Perform the tasks from Step0a and 0b from Question01 here as well.		 
		 */

		/*
		 * Q4Step 1 : In the code below, identify all of SEMANTIC
		 * ERRORS and fix them. You will know you have completed this task when
		 * the program compiles and runs correctly.
		 * 
		 * To fix this program, you need to know what the output should be. READ
		 * the comments at the top of this file to know what this program should do!
		 * 
		 * 
		 * 
		 */

		int width;
		width = 8;
		int height;
		int area = width * height;
		System.out.println(area);

	}
}
