

/**
 * This app derives and prints out the area of a rectangle that is 8 units wide
 * and 3 units high.
 * 
 * @author EECS1720 
 * 
 */
public class Question05 {

	public static void main(String[] args) {
		/*
		 * Perform the tasks from Step0a and 0b from Question01 here as well.		 
		 */

		/*
		 * Q5Step 1 : In the code below, identify all of SEMANTIC
		 * ERRORS and fix them.  You will know you have completed 
		 * this task when the program compiles and runs correctly.
		 */


		
		int width;
		width = 8f;
		int height = 3.0;
		int area = width * height;
		System.out.println(area);

	}
}
