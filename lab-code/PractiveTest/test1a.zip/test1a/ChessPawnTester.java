
import static org.junit.Assert.*;

import java.awt.Color;
import java.lang.reflect.Modifier;
import java.lang.reflect.Field;
import java.util.Random;

import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ChessPawnTester {

	@Rule
	public Timeout globalTimeout = Timeout.seconds(2);

	private static Random rng = new Random();


	/*
	 * 	QUESTION 1 (4 tests)
	 */

	
	@Test
    public void testQ2_00_checkFields() {
        try {
            Class<?> clazz = Class.forName("ChessPawn");
            Field[] fields = clazz.getDeclaredFields();
            
            assertEquals("incorrect number of fields", 3, fields.length);		
    
            for (int i=0; i<fields.length; i++) {
            	assertEquals("at least one field's access modifier is incorrect",true, Modifier.isPrivate(fields[i].getModifiers()));
            	assertEquals("there should be no static fields!!", false, Modifier.isStatic(fields[i].getModifiers()));
            }
            
        } 
        catch (ClassNotFoundException e) {
            fail("Class ChessPawn cannot be found");
        }
    }

	
	@Test
	public void testQ2_01_customCtor1a() {
		
		ChessPawn act = new ChessPawn(Color.white);

		try {
			Field[] fields = act.getClass().getDeclaredFields();
			
			assertEquals("incorrect number of fields", 3, fields.length);
			
			Field pField1 = act.getClass().getDeclaredField("colour");
			pField1.setAccessible(true);
			Color actColour = (Color)pField1.get(act);
			assertEquals("colour field value incorrect",Color.white, actColour);
			
			Field pField2 = act.getClass().getDeclaredField("col");
			pField2.setAccessible(true);
			Character actCol = (Character)pField2.get(act);
			assertEquals("col field value incorrect", ""+'a', ""+actCol.charValue());
			
			Field pField3 = act.getClass().getDeclaredField("row");
			pField3.setAccessible(true);
			Integer actRow = (Integer)pField3.get(act);
			assertEquals("row field value incorrect", 2, actRow.intValue());
			
			
		}
		catch (NoSuchFieldException e) {
			fail("Could not find one of the fields");
		}
		catch (IllegalAccessException e) {
			fail("Cannot access one of the fields");
		}
		
		
	}
	
	@Test
	public void testQ2_02_customCtor1b() {
		
		ChessPawn act = new ChessPawn(Color.black);

		try {
			Field[] fields = act.getClass().getDeclaredFields();
			
			assertEquals("incorrect number of fields", 3, fields.length);
			
			Field pField1 = act.getClass().getDeclaredField("colour");
			pField1.setAccessible(true);
			Color actColour = (Color)pField1.get(act);
			assertEquals("colour field value incorrect",Color.black, actColour);
			
			Field pField2 = act.getClass().getDeclaredField("col");
			pField2.setAccessible(true);
			Character actCol = (Character)pField2.get(act);
			assertEquals("col field value incorrect", ""+'a', ""+actCol.charValue());
			
			Field pField3 = act.getClass().getDeclaredField("row");
			pField3.setAccessible(true);
			Integer actRow = (Integer)pField3.get(act);
			assertEquals("row field value incorrect", 7, actRow.intValue());
			
			
		}
		catch (NoSuchFieldException e) {
			fail("Could not find one of the fields");
		}
		catch (IllegalAccessException e) {
			fail("Cannot access one of the fields");
		}
		
	}
	
	@Test
	public void testQ2_03_customCtor2a() {
		
		ChessPawn act = new ChessPawn(Color.white, 'd',2);

		try {
			Field[] fields = act.getClass().getDeclaredFields();
			
			assertEquals("incorrect number of fields", 3, fields.length);
			
			Field pField1 = act.getClass().getDeclaredField("colour");
			pField1.setAccessible(true);
			Color actColour = (Color)pField1.get(act);
			assertEquals("colour field value incorrect",Color.white, actColour);
			
			Field pField2 = act.getClass().getDeclaredField("col");
			pField2.setAccessible(true);
			Character actCol = (Character)pField2.get(act);
			assertEquals("col field value incorrect", ""+'d', ""+actCol.charValue());
			
			Field pField3 = act.getClass().getDeclaredField("row");
			pField3.setAccessible(true);
			Integer actRow = (Integer)pField3.get(act);
			assertEquals("row field value incorrect", 2, actRow.intValue());
			
			
		}
		catch (NoSuchFieldException e) {
			fail("Could not find one of the fields");
		}
		catch (IllegalAccessException e) {
			fail("Cannot access one of the fields");
		}
		
		
	}
	
	@Test
	public void testQ2_04_customCtor2b() {
		
		ChessPawn act = new ChessPawn(Color.black, 'g',7);

		try {
			Field[] fields = act.getClass().getDeclaredFields();
			
			assertEquals("incorrect number of fields", 3, fields.length);
			
			Field pField1 = act.getClass().getDeclaredField("colour");
			pField1.setAccessible(true);
			Color actColour = (Color)pField1.get(act);
			assertEquals("colour field value incorrect",Color.black, actColour);
			
			Field pField2 = act.getClass().getDeclaredField("col");
			pField2.setAccessible(true);
			Character actCol = (Character)pField2.get(act);
			assertEquals("col field value incorrect", ""+'g', ""+actCol.charValue());
			
			Field pField3 = act.getClass().getDeclaredField("row");
			pField3.setAccessible(true);
			Integer actRow = (Integer)pField3.get(act);
			assertEquals("row field value incorrect", 7, actRow.intValue());
			
			
		}
		catch (NoSuchFieldException e) {
			fail("Could not find one of the fields");
		}
		catch (IllegalAccessException e) {
			fail("Cannot access one of the fields");
		}
		
		
	}
	
	
	@Test(expected = IllegalArgumentException.class)
	public void testQ2_06_ctor2_throws() {

		new ChessPawn(Color.white, 'a', 10);
		new ChessPawn(Color.white, 'i', 2);
		new ChessPawn(Color.white, 'a', 4);
		
		new ChessPawn(Color.black, 'a', 10);
		new ChessPawn(Color.black, 'i', 7);
		new ChessPawn(Color.black, 'a', 4);

	}
	
	
	@Test
	public void testQ2_07_toString() {

		ChessPawn act1 = new ChessPawn(Color.white, 'b',2);
		ChessPawn act2 = new ChessPawn(Color.white, 'f',2);
		ChessPawn act3 = new ChessPawn(Color.black, 'c',7);
		ChessPawn act4 = new ChessPawn(Color.black, 'h',7);
		
		assertEquals("P is at b2",act1.toString());
		assertEquals("P is at f2",act2.toString());
		assertEquals("P is at c7",act3.toString());
		assertEquals("P is at h7",act4.toString());

	}
	
	
	


}
