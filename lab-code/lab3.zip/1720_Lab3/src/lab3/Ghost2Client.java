package lab3;
import java.awt.Color;
import java.io.PrintStream;

public class Ghost2Client {

	public static void main(String[] args) {
		
		// Client application to test Ghost2 class
		
		// Insert your code here to instantiate Ghost2 objects (and modify/print them)
		// as per instructions in the lab3 pdf
		
		

	}

}
