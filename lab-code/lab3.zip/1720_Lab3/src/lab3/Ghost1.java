package lab3;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.io.PrintStream;

import imagePackage.RasterImage;

public class Ghost1 {
	
	
	// CLASS FIELDS =======================================


	
	// CLASS CONSTRUCTORS =================================
	
	/**
	 * Default Constructor
	 */
	public Ghost1() {
		
	
		
	}
	
	/**
	 * Custom Constructor #1
	 * 
	 */
	public Ghost1(int x, int y, int size) {
	
		
	}
	
	/**
	 * Custom Constructor #2
	 * 
	 */
	public Ghost1(int x, int y, int size, Color body, int direction) {
		
		
		
	}
	
	
	// CLASS METHODS ======================================
	
	/**
	 * A method that outputs the state of a Ghost1 object (as per the lab3 pdf output examples)
	 * 
	 */
	public String toString() {
		
		
	}
	
	
	// MAIN METHOD ===============



	public static void main(String[] args) {
		/*
		 * 
		 * In this task, you are to create a class to support the positioning, size, 
		 * color of a Ghost object (to mimic the ghost characters in a pacman-like game)
		 * 
		 * To achieve this, you will need to:
		 * 
		 * 1. create class variables as per the UML diagram given in Question01 in the lab3 pdf 
		 * 
		 * 2. create a default constructor as per the UML diagram given (see lab3 pdf)
		 * 
		 * 3. create 2 custom constructors as per the UML diagram given, (see lab3 pdf)
		 * 
		 *
		 * 4. Use your main method as a client application to test the above (see lab3 pdf for instructions)
		 * 
		 * 5. Run the PartialTester.java to check the functionality of these classes
		 * 
		 * 
		 */
		
		
		
		
		
		
	}
}
