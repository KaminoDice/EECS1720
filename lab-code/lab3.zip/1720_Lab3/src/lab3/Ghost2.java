package lab3;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.io.PrintStream;

import imagePackage.RasterImage;

public class Ghost2 {


	// CLASS FIELDS =======================================

	


	// CLASS CONSTRUCTORS =================================

	/**
	 * Default Constructor
	 */
	public Ghost2() {

		
	}

	/**
	 * Custom Constructor #1
	 */
	public Ghost2(int x, int y, int size) {

		
	}

	/**
	 * Custom Constructor #2
	 * 
	 */
	public Ghost2(int x, int y, int size, Color body, int direction) {

		

	}


	// CLASS METHODS ======================================

	/**
	 * A method that outputs the state of a Ghost1 object (as per the lab3 pdf output examples)
	 * 
	 */
	public String toString() {

		

	}


	// GETTERS =========
	



	// SETTERS =========
	
	
	
	// MAIN METHOD === (not needed, use Ghost2Client.java instead) ============


	public static void main(String[] args) {
		/*
		 * 
		 * In this task, you will copy over the code from Q1, rename constructors, then
		 * modify the class:  
		 * 
		 * first, by locking off the fields of the ghost so they are not public,
		 * 
		 * then by adding getters/setters to support public access and mutation of some of these
		 * fields (as specified by the instructions for Q2 in the lab3 pdf, and UML diagram)
		 */


		

	}
}
